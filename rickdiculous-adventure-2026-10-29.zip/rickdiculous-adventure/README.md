# Rickdiculous Adventure

A browser game built with Three.js. It runs on your own computer. You don't need a Claude account, a GitHub account or an internet login. Don't double-click `index.html`, because the browser blocks the game's files unless a local server is running.

## Mac
1. Unzip this file.
2. Open Terminal. Type `cd ` with a trailing space, drag this folder into the window, and press Return.
3. Run `python3 -m http.server 8000`. If macOS offers to install developer tools, accept, then run the command again.
4. Open http://localhost:8000 in your browser.

## Windows
1. Right-click the zip, choose **Extract All…**, and open the extracted `rickdiculous-adventure` folder.
2. If you don't have Python, install it from https://www.python.org/downloads/ and check **"Add python.exe to PATH"** on the first screen.
3. In File Explorer, click the address bar, type `cmd`, and press Enter.
4. Run `python -m http.server 8000`. If that fails, use `py -m http.server 8000`.
5. Open http://localhost:8000 in Chrome or Edge.

Leave the Terminal or Command Prompt window open while you play. Press Ctrl+C or close the window to stop.

## Notes
- Online multiplayer and the shared leaderboard only work on claude.ai. Single-player runs normally here.
- Connect your controller before you open the page.
- The 3D models are third-party Sketchfab assets. Full credits and licenses are on the game's credits screen.
- This is an unofficial, non-commercial fan project.
